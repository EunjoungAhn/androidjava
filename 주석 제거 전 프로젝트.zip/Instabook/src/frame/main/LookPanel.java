package frame.main;

import javax.swing.JPanel;


import db.PostDAO;
import db.PostVO;
import db.UserDAO;

import javax.swing.JLabel;
import java.awt.Image;
import javax.swing.ImageIcon;

public class LookPanel extends JPanel {
	
	static PostVO postVo = new PostVO();
	PostDAO postDao = new PostDAO();
	static JLabel look_mainPicLabel = new JLabel();
	private static final long serialVersionUID = 1L;

	/**
	 * @wbp.parser.entryPoint
	 * 
	 */

	public LookPanel(String postId) {

		PostVO postVo = PostDAO.getPostInfo(postId);
		String userImg = UserDAO.getProfile(postVo.getId_user());
		String name = UserDAO.getNickname(postVo.getId_user());
		String postImg = postVo.getImg_post();
		int like = postVo.getLike_post();
		String hash = postVo.getHash_post();
		String date = postVo.getDate_post();

		setLayout(null);
		setSize(600, 900);
		setBounds(40, 40, 492, 650);

		JLabel look_NickName_Label = new JLabel("닉네임 : " + name);
		look_NickName_Label.setBounds(240, 32, 102, 34);
		add(look_NickName_Label);

		// 프로필 이미지 적용.
		ImageIcon img = new ImageIcon(userImg);
		Image pic = img.getImage(); // ImageIcon을 Image로 변환.(객체를 돌려준다.)
		Image picCh = pic.getScaledInstance(90, 90, java.awt.Image.SCALE_SMOOTH);// 이미지 사이즈 조정
		ImageIcon iconCh = new ImageIcon(picCh); // Image로 ImageIcon 생성
		JLabel look_headPic_Label = new JLabel("프로필 사진");
		look_headPic_Label.setBounds(70, 10, 90, 90);
		look_headPic_Label.setIcon(iconCh);
		add(look_headPic_Label);

		JLabel look_day_Label = new JLabel();
		look_day_Label.setBounds(60, 469, 183, 27);
		add(look_day_Label);

		JLabel look_hash_Label = new JLabel();
		look_hash_Label.setBounds(60, 506, 218, 60);
		add(look_hash_Label);

		JLabel look_like_Label = new JLabel();
		look_like_Label.setBounds(260, 473, 80, 15);
		add(look_like_Label);

		look_mainPicLabel = new JLabel();

		// 버튼 글자 테두리 없애기
		look_headPic_Label.setFocusable(false);

		try {
			postVo = postDao.lookRead(postId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ImageIcon look_img = new ImageIcon(postImg);
		Image look_pic = look_img.getImage(); // ImageIcon을 Image로 변환.(객체를 돌려준다.)
		Image look_picCh = look_pic.getScaledInstance(250, 250, java.awt.Image.SCALE_SMOOTH);// 이미지 사이즈 조정
		ImageIcon look_iconCh = new ImageIcon(look_picCh); // Image로 ImageIcon 생성

		look_mainPicLabel.setIcon(look_iconCh);
		// 스크롤패널 버튼적용
		look_mainPicLabel.setBounds(60, 80, 377, 368);
		add(look_mainPicLabel);

		look_day_Label.setText("게시일 : "+ date);
		look_hash_Label.setText("해쉬태그 : "+hash);
		look_like_Label.setText("좋아요 : "+String.valueOf(like));

		setVisible(true);
	}

}
